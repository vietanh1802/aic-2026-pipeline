import { useCallback, useEffect, useState } from "react";

import App from "./App";
import { getAnswers } from "./api/answers";
import { me } from "./api/auth";
import { getBoard, heartbeat, type BoardTask } from "./api/board";
import { canSubmitDres, getDresStatus, listDresSubmissions } from "./api/dres";
import AnswerBasket from "./components/AnswerBasket";
import AppNav, { type Screen } from "./components/AppNav";
import Board from "./pages/Board";
import ChangePassword from "./pages/ChangePassword";
import DresPage from "./pages/Dres";
import EvaluationPage from "./pages/Evaluation";
import RetrievalBenchmark from "./pages/RetrievalBenchmark";
import ExportPage from "./pages/Export";
import ImportPack from "./pages/ImportPack";
import Login from "./pages/Login";
import { useAuthStore } from "./store/authStore";
import { usePopupStore } from "./store/popupStore";

const HEARTBEAT_MS = 10000;

/**
 * All of the routing there is. A router library buys nothing while there are
 * four screens and no URL worth sharing, and it would mean restructuring
 * App.tsx — which stays exactly the search screen it already is.
 *
 * Every hook runs before the first return, because the number of hooks a
 * component calls may not change between renders.
 */
export default function Root() {
  const token = useAuthStore((state) => state.token);
  const user = useAuthStore((state) => state.user);
  const setUser = useAuthStore((state) => state.setUser);

  const [screen, setScreen] = useState<Screen>("board");
  const [task, setTask] = useState<BoardTask | null>(null);
  const [answerCount, setAnswerCount] = useState(0);
  const [rowsPerQuery, setRowsPerQuery] = useState(100);
  const [basketOpen, setBasketOpen] = useState(false);
  // Name of the round that took over, set when a held task was dropped because
  // its round was retired. Cleared by the next navigation.
  const [roundChanged, setRoundChanged] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      return;
    }
    // A token restored from localStorage may already be dead, and only the
    // server knows. apiFetch clears the store on 401, so this both refreshes
    // the user and evicts a stale session on reload.
    void me()
      .then((response) => setUser(response.user))
      .catch(() => undefined);
  }, [token, setUser]);

  // Also the guard against working into a round that is no longer live.
  //
  // An admin switching rounds does not reach into anyone's open tab, so a
  // member holding task 07 of the round that was just retired would carry on
  // answering into it — work that no export would ever pick up. Polled on the
  // same timer as presence, and the held task is dropped the moment its round
  // stops being the active one.
  useEffect(() => {
    if (!token) {
      return;
    }
    let cancelled = false;
    const check = async () => {
      try {
        const board = await getBoard();
        if (cancelled) {
          return;
        }
        setRowsPerQuery(board.round?.rows_per_query ?? 100);
        setTask((held) => {
          if (!held || !board.round || held.pack_id === board.round.id) {
            return held;
          }
          setRoundChanged(board.round.label);
          setScreen("board");
          return null;
        });
      } catch {
        // A failed poll is not worth a message; the next one is 10s away.
      }
    };
    void check();
    const timer = window.setInterval(() => void check(), HEARTBEAT_MS);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [token]);

  // Presence: tells teammates which task you are looking at. Cheap enough to
  // send on a timer, and it is the only thing keeping the viewer list honest.
  useEffect(() => {
    if (!token || !user || user.must_change_password) {
      return;
    }
    const beat = () => void heartbeat(task?.id ?? null).catch(() => undefined);
    beat();
    const timer = window.setInterval(beat, HEARTBEAT_MS);
    return () => window.clearInterval(timer);
  }, [token, user, task]);

  // Người duyệt được phải biết có đề xuất DRES mới cả khi đang ở màn Search —
  // đó là lúc họ cũng đang tìm. Câu chung kết mất 10 điểm mỗi phút, nên 5 giây
  // chứ không đi chung nhịp 10 giây của board.
  //
  // "Người duyệt được" tuỳ chế độ nộp: chỉ admin, hoặc cả đội khi admin bật
  // "Mọi người nộp được". Nên đọc lại chế độ mỗi nhịp, không chỉ xem role.
  const [dresPending, setDresPending] = useState(0);
  const role = user?.role;
  useEffect(() => {
    if (!token) {
      return;
    }
    const poll = () =>
      void Promise.all([getDresStatus(), listDresSubmissions(50)])
        .then(([status, { submissions }]) =>
          setDresPending(
            canSubmitDres(role, status)
              ? submissions.filter((s) => s.status === "proposed").length
              : 0
          )
        )
        .catch(() => undefined);
    poll();
    const timer = window.setInterval(poll, 5000);
    return () => window.clearInterval(timer);
  }, [token, role]);

  const refreshCount = useCallback(async () => {
    if (!task) {
      setAnswerCount(0);
      return;
    }
    try {
      setAnswerCount((await getAnswers(task.id)).answers.length);
    } catch {
      // The count is decoration; a failed poll is not worth a message.
    }
  }, [task]);

  useEffect(() => {
    void refreshCount();
  }, [refreshCount, basketOpen]);

  if (!token || !user) {
    return <Login />;
  }
  if (user.must_change_password) {
    return <ChangePassword />;
  }

  return (
    <>
      <AppNav
        screen={screen}
        onNavigate={(next) => {
          setRoundChanged(null);
          setScreen(next);
        }}
        user={user}
        task={task}
        answerCount={answerCount}
        rowsPerQuery={rowsPerQuery}
        onOpenBasket={() => setBasketOpen(true)}
        dresPending={dresPending}
      />

      {roundChanged !== null && (
        <div className="px-4 py-2 bg-[#d4a017]/15 border-b border-[#d4a017] text-[13px] text-[#8a6a0f] font-baloo">
          Vòng thi đã đổi sang <b>{roundChanged}</b>. Task bạn đang mở thuộc vòng
          cũ nên đã được đóng lại — nhận task mới từ bảng bên dưới.
        </div>
      )}

      {screen === "board" && (
        <Board
          onOpenTask={(picked, options) => {
            setRoundChanged(null);
            setTask(picked);
            setScreen("search");
            // Opening a teammate's task from the count is a request to see
            // what is in it, not to start searching.
            setBasketOpen(options?.openBasket === true);
          }}
        />
      )}
      {screen === "evaluation" && <EvaluationPage />}
      {screen === "retrieval-benchmark" && <RetrievalBenchmark />}
      {screen === "import" && <ImportPack />}
      {screen === "export" && <ExportPage />}
      {screen === "dres" && (
        <DresPage
          onOpenVideo={(videoId, frameIdx) => {
            // Cùng đường với giỏ đáp án: popup sống trong App.
            setScreen("search");
            usePopupStore.getState().open(videoId, frameIdx);
          }}
        />
      )}

      {/* Kept mounted rather than unmounted, so switching to the board and back
          does not throw away the current search results.

          Màn "Lịch sử" cũng nằm trong cây này chứ không phải một trang riêng ở
          Root: bấm "Coi X làm" phải áp truy vấn vào ô search rồi chạy lại, mà
          hàm làm việc đó sống trong App. Dựng nó ở Root sẽ phải luồn ngược
          hàm ấy lên qua hai tầng. */}
      <div hidden={screen !== "search" && screen !== "history"}>
        <App
          activeTask={task}
          rowsPerQuery={rowsPerQuery}
          onBasketChanged={() => void refreshCount()}
          view={screen === "history" ? "history" : "search"}
          onLeaveHistory={() => setScreen("search")}
        />
      </div>

      <AnswerBasket
        task={task}
        rowsPerQuery={rowsPerQuery}
        open={basketOpen}
        onClose={() => {
          setBasketOpen(false);
          void refreshCount();
        }}
        onOpenVideo={(videoId, frameIdx) => {
          // The popup lives inside App, which Root hides on every other screen.
          // Opening it from the basket has to bring the search screen with it.
          setScreen("search");
          usePopupStore.getState().open(videoId, frameIdx);
        }}
      />
    </>
  );
}
